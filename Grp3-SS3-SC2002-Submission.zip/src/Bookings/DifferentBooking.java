package Bookings;

/**
 * Interface for different booking class
 */
public interface DifferentBooking {

    //abstract methods
    /**
     * Abstract class
     * @return double booking price
     */
    public double booking();

    
}
