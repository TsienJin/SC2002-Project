package MovieTheatres;

/**
 * Theatre class is a superclass to First, Gold and Regular
 */
public interface Theatre {

    public void initialLayout();
    public void printInitialLayout();
    public void showLayout();
    

    
}
