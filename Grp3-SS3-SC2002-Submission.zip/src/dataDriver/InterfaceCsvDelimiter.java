package dataDriver;


/** Specifies deleminiters for CSV file
 * 
 */
public interface InterfaceCsvDelimiter {
    final String mainDelimiter = ",";
    final String subDelimiter = "&";
}
