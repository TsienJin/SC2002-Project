package dataDriver;


/** Interface that specifies toCsvString method
 * 
 */
public interface InterfaceToCsvStringHelper {
    public String toCsvString();
}
